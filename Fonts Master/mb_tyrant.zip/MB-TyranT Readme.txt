MB-TyranT Gothic Font by ModBlackmoon [hand-drawn].
Incl. English and European letters.

Free for personal use, but shareware for any public or commercial use.
Sharing this font on the other web-sites is forbidden.
Hi-Res Sharp PSD Letters aviable for commercial use.

http://modblackmoon.narod.ru/